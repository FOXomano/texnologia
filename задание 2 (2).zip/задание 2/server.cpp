#include "server.h"
#include <QDebug>

Server::Server(QObject *parent)
    : QTcpServer(parent), maxClients(9)
{
}

bool Server::startServer(quint16 port, int maxClients)
{
    this->maxClients = maxClients;

    if (!listen(QHostAddress::Any, port)) {
        qDebug() << "Не удалось запустить сервер:" << errorString();
        return false;
    }

    qDebug() << "Сервер запущен на порту" << port << ". Максимум клиентов:" << maxClients;
    return true;
}

void Server::onNewConnection()
{
    if (clients.size() >= maxClients) {
        QTcpSocket *socket = nextPendingConnection();
        socket->write("Сервер занят. Подключитесь позднее.\r\n");
        socket->disconnectFromHost();
        return;
    }

    QTcpSocket *client = nextPendingConnection();
    clients.insert(client, "Guest_" + QString::number(clients.size() + 1));

    client->write("Добро пожаловать на сервер!\r\n");
    client->write("Установите ник командой: /nick <имя>\r\n");

    connect(client, &QTcpSocket::readyRead, this, &Server::onReadyRead);
    connect(client, &QTcpSocket::disconnected, this, &Server::onClientDisconnected);

    updateClientCount();
}

void Server::onReadyRead()
{
    QTcpSocket *client = qobject_cast<QTcpSocket*>(sender());
    if (!client) return;

    while (client->canReadLine()) {
        QByteArray data = client->readLine().trimmed();
        QString message = QString::fromUtf8(data);

        if (!processCommand(client, message)) {
            QString clientNick = clients.value(client);
            QString broadcastMessage = clientNick + ": " + message;
            sendToAll(broadcastMessage);
        }
    }
}

void Server::onClientDisconnected()
{
    QTcpSocket *client = qobject_cast<QTcpSocket*>(sender());
    if (!client) return;

    QString nick = clients.value(client);
    clients.remove(client);

    qDebug() << "Клиент отключился:" << nick;
    client->deleteLater();

    updateClientCount();
}

void Server::sendToAll(const QString &message)
{
    QByteArray data = message.toUtf8() + "\r\n";

    for (QTcpSocket *client : clients.keys()) {
        if (client->state() == QTcpSocket::ConnectedState) {
            client->write(data);
        }
    }
}

void Server::updateClientCount()
{
    QString countMessage = "Текущее количество подключенных клиентов: " +
                        QString::number(clients.size());
    sendToAll(countMessage);
}

bool Server::processCommand(QTcpSocket *client, const QString &message)
{
    if (message.startsWith("/nick ")) {
        QString newNick = message.mid(6).trimmed();

        if (newNick.isEmpty()) {
            client->write("Ошибка: ник не может быть пустым.\r\n");
            return true;
        }

        bool nickExists = false;
        for (const QString &existingNick : clients) {
            if (existingNick == newNick) {
                nickExists = true;
                break;
            }
        }

        if (nickExists) {
            client->write("Ошибка: этот ник уже занят.\r\n");
            return true;
        }

        QString oldNick = clients.value(client);
        clients[client] = newNick;

        client->write(("Ник изменен на: " + newNick + "\r\n").toUtf8());
        qDebug() << "Ник изменен:" << oldNick << "->" << newNick;
        return true;
    }
    else if (message.startsWith("/pm ")) {
        QStringList parts = message.split(' ', Qt::SkipEmptyParts);
        if (parts.size() < 3) {
            client->write("Использование: /pm <ник> <сообщение>\r\n");
            return true;
        }

        QString targetNick = parts[1];
        QString privateMessage = message.mid(message.indexOf(' ', 4) + 1);

        QTcpSocket *targetClient = nullptr;
        for (auto it = clients.begin(); it != clients.end(); ++it) {
            if (it.value() == targetNick) {
                targetClient = it.key();
                break;
            }
        }

        if (!targetClient) {
            client->write(("Ошибка: пользователь " + targetNick + " не найден.\r\n").toUtf8());
            return true;
        }

        QString senderNick = clients.value(client);
        QString pmMessage = "ЛИЧНОЕ (" + senderNick + " -> " + targetNick + "): " + privateMessage;

        targetClient->write((pmMessage + "\r\n").toUtf8());
        client->write(("Сообщение отправлено " + targetNick + ": " + privateMessage + "\r\n").toUtf8());

        return true;
    }

    return false;
}
