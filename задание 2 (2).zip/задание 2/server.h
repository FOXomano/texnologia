#ifndef SERVER_H
#define SERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QMap>
#include <QString>

class Server : public QTcpServer
{
    Q_OBJECT

public:
    Server(QObject *parent = nullptr);
    bool startServer(quint16 port, int maxClients = 9);

private slots:
    void onNewConnection();
    void onReadyRead();
    void onClientDisconnected();

private:
    int maxClients;
    QMap<QTcpSocket*, QString> clients; // Сопоставление сокета и никнейма

    void sendToAll(const QString &message);
    void updateClientCount();
    bool processCommand(QTcpSocket *client, const QString &message);
};

#endif // SERVER_H
