#include <QCoreApplication>
#include "server.h"

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    TCPServer server;
    if (!server.listen(QHostAddress::Any, 1234)) {
        qCritical() << "Failed to start server:" << server.errorString();
        return 1;
    }

    qInfo() << "Server started on port 1234";
    return app.exec();
}
