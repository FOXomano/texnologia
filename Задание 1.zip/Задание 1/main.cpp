#include <QTcpServer>
#include <QTcpSocket>
#include <QCoreApplication>
#include <QTextStream>
#include <QDebug>

class TcpServer : public QObject {
    Q_OBJECT
public:
    explicit TcpServer(QObject *parent = nullptr) : QObject(parent) {
        server = new QTcpServer(this);
        connect(server, &QTcpServer::newConnection, this, &TcpServer::onNewConnection);

        quint16 port = 1234;
        if (server->listen(QHostAddress::Any, port)) {
            qDebug() << "Server started on port" << port;
        } else {
            qDebug() << "Failed to start server:" << server->errorString();
        }
    }

private slots:
    void onNewConnection() {
        QTcpSocket *client = server->nextPendingConnection();
        qDebug() << "New connection from" << client->peerAddress().toString();

        QTextStream stream(client);
        stream << "Hello from Arch Linux TCP Server!\r\n";
        stream.flush();

        connect(client, &QTcpSocket::disconnected, client, &QTcpSocket::deleteLater);
    }

private:
    QTcpServer *server;
};

int main(int argc, char *argv[]) {
    QCoreApplication app(argc, argv);
    TcpServer srv;
    return app.exec();
}

#include "main.moc"
