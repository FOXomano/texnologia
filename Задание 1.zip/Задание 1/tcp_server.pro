QT       += core network
QT       -= gui

TARGET = arch_server
CONFIG   += console c++17
CONFIG   -= app_bundle

TEMPLATE = app

SOURCES += main.cpp
